﻿<%@ Application Codebehind="Global.asax.cs" Inherits="BankPortal.MvcApplication" Language="C#" %>
